#ifndef HELPERS_H
#define HELPERS_H

void replace_word(char *line, const char *old, const char *new);

#endif
