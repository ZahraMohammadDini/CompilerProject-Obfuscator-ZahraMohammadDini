#ifndef OBFUSCATOR_H
#define OBFUSCATOR_H

void obfuscate(const char *input_file, const char *output_file);

#endif
